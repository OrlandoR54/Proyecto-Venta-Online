<?php
session_start();
if (!isset($_SESSION['isLogged']) || $_SESSION['isLogged'] === FALSE) {
    header("Location: \Proyecto-Venta-Online\Public\Vista\login.html");
    
}
?>
<!DOCTYPE html>
<html>

<?php
include '../../config/conexionBD.php';
//$per_id = $_GET['per_id'];
//$rol_user=$_GET['rol_user'];
$codigo=$_GET["codigo"];
?>

<head>
    <meta charset="UTF-8">
    <title>Pagina principal administrador</title> 
    <link rel="stylesheet" href="../../css/styles.css">
    <link rel="stylesheet" href="../../css/structure.css">
</head>

<body>

    <!-- Barra navegador (acentada arriba) -->
    <div class="cabecera">
        <div class="barra cabColor espAmplio margRelleno sombra">
            <a href="indexUser.php?codigo=<?php echo $codigo ?>" class="barraItem boton"><b>CBD</b> Cannabidiol</a>
            <!-- enlaces flotantes a la derecha. Econdiendoles en una pantallas pequeñas -->
            <div class="derecha">
                <a href="indexUser.php?codigo=<?php echo $codigo ?>" class="barraItem boton">Home</a>
                <a href="catalogoUser.php?codigo=<?php echo $codigo ?>" class="barraItem boton">Productos</a>
                <a href="aboutUser.php?codigo=<?php echo $codigo ?>" class="barraItem boton">About</a>
                <a href="../../Private/Controlador/GestionUsuario/mi_cuenta.php?codigo=<?php echo $codigo ?>" class="barraItem boton">Mi Cuenta</a>
                <a href="../../config/cerrar_sesion.php" class="barraItem boton">&#128682;Cerrar Sesion</a>
                <a href="../Productos/carrito.php?codigo=<?php echo $codigo ?>"><i class="carro-compras carro-derecha"></i></a>
            </div>
        </div>
    </div>
    <!----------Fin de barra navegador---------->


    <!-- Header -->
    <header class="visualContent contenido espAmplio" style="max-width:1500px;" id="home">

        <div class="slider-contenedor sombra slider-wrapper">

            <div class="slides fade">
                <div class="numText">1 / 3</div>
                <img src="../../images/cannabidiol-science-lexaria.jpeg" style="width:100%">
                <div class="mostrar-medio margen-arriba centro">
                    <h1 class="tamLetra colLetra"><span class="margRelleno colLogo opacidad"><b>CBD</b></span>
                    <span class="txtLight">Cannabidiol</span></h1>
                </div>
               <div class="text">Caption Text</div>
            </div>

            <div class="slides fade">
                <div class="numText">2 / 3</div>
                <img src="../../images/cannabidiol.jpg" style="width:100%">
                <div class="mostrar-medio margen-arriba centro">
                <h1 class="tamLetra colLetra"><span class="margRelleno colLogo opacidad"><b>CBD</b></span>
                    <span class="txtLight">Cannabidiol</span></h1>
                </div>
                <div class="text">Caption Two</div>
            </div>

            <div class="slides fade">
                <div class="numText">3 / 3</div>
                <img src="../../images/CBD.jpg" style="width:100%">
                <div class="mostrar-medio margen-arriba centro">
                    <h1 class="tamLetra colLetra"><span class="margRelleno colLogo opacidad"><b>CBD</b></span>
                    <span class="txtLight">Cannabidiol</span></h1>
                </div>
                <div class="text">Caption Three</div>
            </div>

            <a class="atras" onclick="plusSlides(-1)">&#10094;</a>
            <a class="siguiente" onclick="plusSlides(1)">&#10095;</a>

        </div>
    <br>

        <div style="text-align:center">
            <span class="dot" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
        </div>
    </header>
    <!----------------------------------------Fin Header---------------------------------------->
    <!-- Seccion CBD -->
    <div class="w3-twothird">
    <div class="contenedor relleno-32 cont-inf card w3-margin-bottom">
    <h3 class="borde-inferior color-borde relleno-16">¿Qué es CBD?</h3>
    <p>CBD significa cannabidiol. Es el segundo ingrediente activo más frecuente del cannabis (marihuana). Si bien el
        CBD es un componente esencial de la marihuana medicinal, se deriva directamente de la planta de cáñamo, que es
        un
        primo de la planta de marihuana. Si bien el CBD es un componente de la marihuana (uno de cientos), por sí solo
        no
        causa un "subidón". Según un informe de la Organización Mundial de la Salud, "en los humanos, el CBD no exhibe
        efectos indicativos de ningún potencial de abuso o dependencia ... Hasta la fecha, no hay evidencia de problemas
        relacionados con la salud pública asociados con el uso de CBD puro ".
    </p>
    </div>
    </div>
    <!-- Seccion CBD Beneficios -->
    <div class="w3-twothird">
    <div class="contenedor relleno-32 cont-inf card">
    <h3 class="borde-inferior color-borde relleno-16">Beneficios del CBD</h3>
    <p>El CBD ha sido promocionado por una amplia variedad de problemas de salud, pero la evidencia científica más
        sólida es su efectividad en el tratamiento de algunos de los síndromes de epilepsia infantil más crueles, como
        el
        síndrome de Dravet y el síndrome de Lennox-Gastaut (LGS), que generalmente no responden a medicamentos
        anticonvulsivos. En numerosos estudios, el CBD pudo reducir la cantidad de convulsiones y, en algunos casos,
        pudo
        detenerlas por completo. Los videos de los efectos del CBD en estos niños y sus ataques están fácilmente
        disponibles en Internet para su visualización, y son bastante sorprendentes. Recientemente, la FDA aprobó el
        primer medicamento derivado del cannabis para estas afecciones, Epidiolex, que contiene CBD.
    </p>
    </div>
    </div>


    <!-- Page content -->
    <div class="w3-content w3-padding" style="max-width:1564px">

    <!-- Project Section -->
    <div class="w3-container relleno-32" id="projects">
    <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">CBD</h3>
    </div>

    <div class="w3-row-padding">
    <div class="w3-col l3 m6 w3-margin-bottom">
        <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Summer House</div>
        <img src="../../images/THC-CBD.jpg" alt="House" style="width:100%">
        </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
        <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Brick House</div>
        <img src="../../images/cbd pills.jpg" alt="House" style="width:100%">
        </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
        <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Renovated</div>
        <img src="../../images/Speaking.jpg" alt="House" style="width:100%">
        </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
        <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Barn House</div>
        <img src="../../images/canna.jpg" alt="House" style="width:100%">
        </div>
    </div>
    </div>


    <div class="fila-relleno w3-grayscale">
    <div class="w3-col l3 m6 w3-margin-bottom" id="media">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/zNT8Zo_sfwo" frameborder="0"
        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <h3>Parkinson</h3>
        <p class="w3-opacity">Cannabidiol</p>
        <p>Vea los efectos del cannabis de primera mano, sin editar, sobre la discinesia por temblor de Parkinson y la
        voz.</p>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom" id="media">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/_DvN1iziHpM" frameborder="0"
        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <h3>Aceite CBD</h3>
        <p class="w3-opacity">Cannabidiol</p>
        <p>El CBD o aceite de cánnabis, para que se usa, cuáles son sus beneficios. <br> <br> </p>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom" id="media">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/O3RunGD7tBs" frameborder="0"
        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <h3>Epilepsia</h3>
        <p class="w3-opacity">Cannabidiol</p>
        <p>Con un extracto de cannabis, las convulsiones de este niño se detuvieron en menos de un minuto.</p>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom" id="media">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/1iIENII-lVo" frameborder="0"
        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <h3>THC VS CBD</h3>
        <p class="w3-opacity">Cannabidiol</p>
        <p>Conoce la diferencia entre el THC y CBD y que efectos tienen en tu cuerpo. <br> <br> </p>
    </div>
    <p> <a href="about.html"><button class="w3-button w3-light-grey w3-block">Contactanos</button></a></p>
    </div>

    <!-- End page content -->
    </div>


    <!-- Pie de pagina -->
    <footer class="centro colLogo relleno-16">
    <div>
    &#8226; Cannabidiol &#8226;
    </div>
    <p><em>Copyright &copy; </em> <em> 2019 Todos los derechos reservados</em></p>
    <div class="iconos-sociales">
    <a href="https://www.facebook.com/hugo.zhindon.1" target="_blank"><img class="icono" alt="Sígueme en Facebook"
        height="35" width="35"
        src="https://2.bp.blogspot.com/-28mh2hZK3HE/XCrIxxSCW0I/AAAAAAAAH_M/XniFGT5c2lsaVNgf7UTbPufVmIkBPnWQQCLcBGAs/s1600/facebook.png"
        title="Sígueme en Facebook" /></a>
    <a href="https://www.instagram.com/dailyart_viral/" target="_blank"><img class="icono" alt="Sígueme en Facebook"
        height="35" width="35"
        src="https://4.bp.blogspot.com/-Ilxti1UuUuI/XCrIy6hBAcI/AAAAAAAAH_k/QV5KbuB9p3QB064J08W2v-YRiuslTZnLgCLcBGAs/s1600/instagram.png"
        title="Sígueme en Instagram" /></a>
    <a href="https://www.youtube.com/watch?v=apXnm90fpwo" target="_blank"><img class="icono" alt="Sígueme en Facebook"
        height="35" width="35"
        src="https://1.bp.blogspot.com/-CUKx1kAd-ls/XCrI4UAvNqI/AAAAAAAAIBI/-i1neUt8kZwP6YOsFOXX5p0Bnqa29m-JgCLcBGAs/s1600/youtube2.png"
        title="Sígueme en YouTube" /></a>
    </div>
    </footer>
    <script src="JavaScript/index.js"></script>

   
</body>

</html>